# MHL-synth-tech-week-2-boilers     
#### for student in _Sound Synthesis Techniques and Creative Coding_   

Download this folder by clicking on the green `<>Code` button (above),   
then choose `Download ZIP`   

Unzip the file that shows up inside your Downloads folder   
Move this folder into your Week 2 class folder to begin using it...  
