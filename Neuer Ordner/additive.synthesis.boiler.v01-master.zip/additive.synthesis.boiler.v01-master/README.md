# additive.synthesis.boiler.v01
#### for student in _Sound Synthesis Techniques and Creative Coding_   

Download this folder by clicking on the green `<>Code` button (above),   
then choose `Download ZIP`   

Unzip the file that shows up inside your Downloads folder   
Move this folder into your Week 3 class folder to begin using it...  
